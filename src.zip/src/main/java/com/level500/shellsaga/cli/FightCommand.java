package com.level500.shellsaga.cli;

import com.level500.shellsaga.core.game.characters.Enemy;
import com.level500.shellsaga.core.game.characters.Player;
import com.level500.shellsaga.core.game.combat.CombatSystem;
import com.level500.shellsaga.core.game.locations.Area;
import com.level500.shellsaga.infrastructure.database.AreaRepository;
import com.level500.shellsaga.infrastructure.database.EnemyRepository;
import com.level500.shellsaga.services.PlayerService;
import org.jline.reader.LineReader;
import org.jline.reader.LineReaderBuilder;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class FightCommand implements GameCommand{
    private final PlayerService playerService;
    private final EnemyRepository enemyRepository;
    private final LineReader reader;
    private final AreasCommand areasCommand;
    private final AreaRepository areaRepository;

    @Autowired
    public FightCommand(PlayerService playerService, EnemyRepository enemyRepository, AreasCommand areasCommand, AreaRepository areaRepository) throws Exception {
        this.playerService = playerService;
        this.enemyRepository = enemyRepository;
        this.areasCommand = areasCommand;
        this.areaRepository = areaRepository;
        Terminal terminal = TerminalBuilder.builder().system(true).build();
        this.reader = LineReaderBuilder.builder().terminal(terminal).build();

    }

    @Override
    public void execute() {
        String playerIdInput = reader.readLine("\nEnter your player ID: ").trim();
        long playerId;
        try {
            playerId = Long.parseLong(playerIdInput);
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid input. Please enter a valid numeric player ID.");
            return;
        }

        Long storedPlayerId = areasCommand.getStoredPlayerId(playerId); // ✅ Get stored session for player
        if (storedPlayerId == null) {
            System.out.println("❌ You must select an area first before fighting an enemy.");
            return;
        }

        Optional<Player> optionalPlayer = playerService.getPlayerById(storedPlayerId);
        if (optionalPlayer.isEmpty()) {
            System.out.println("❌ Player not found! Please enter a valid player ID.");
            return;
        }

        Player player = optionalPlayer.get();
        String currentAreaName = player.getCurrentArea();

        if (currentAreaName == null) {
            System.out.println("❌ You have not entered any area. Use 'areas' to move to a location first.");
            return;
        }

        System.out.println("\n⚔️ Searching for enemies in " + currentAreaName + "...");

        Optional<Area> optionalArea = areaRepository.findByName(currentAreaName);
        if (optionalArea.isEmpty()) {
            System.out.println("❌ Error: Area not found in the database.");
            return;
        }

        Area selectedArea = optionalArea.get();
        List<Enemy> enemies = enemyRepository.findByAreaAndLevelGreaterThanEqual(selectedArea, player.getLevel());

        if (enemies.isEmpty()) {
            System.out.println("\n🛡️ This area seems safe... No enemies found!");
            return;
        }

        System.out.println("\n⚔️ Choose an enemy to fight:");
        for (int i = 0; i < enemies.size(); i++) {
            System.out.println((i + 1) + ". " + enemies.get(i).getName() + " (Level: " + enemies.get(i).getLevel() + ")");
        }

        String choiceInput = reader.readLine("\nEnter the number of the enemy you want to fight: ").trim();
        int choice;
        try {
            choice = Integer.parseInt(choiceInput);
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid input. Please enter a valid number.");
            return;
        }

        if (choice < 1 || choice > enemies.size()) {
            System.out.println("❌ Invalid selection. Please try again.");
            return;
        }

        Enemy selectedEnemy = enemies.get(choice - 1);
        System.out.println("\n🔥 You have selected to fight: " + selectedEnemy.getName() + " (Level: " + selectedEnemy.getLevel() + ")");

        // ✅ Transition to Combat Mode
        CombatSystem.startBattle(player, selectedEnemy);
    }
}
