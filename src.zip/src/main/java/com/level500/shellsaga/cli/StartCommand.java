package com.level500.shellsaga.cli;

import org.springframework.stereotype.Component;

//✔ Executes when the player types start.
@Component
public class StartCommand implements GameCommand{

    @Override
    public void execute() {
        System.out.println("\uD83C\uDFAE The game has started! Type 'help to see available commands.");
        HelpCommand.setGameStarted(true);
        // Here we can initialize player creation and game mechanics
    }
}
