package com.level500.shellsaga.core.game.characters;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.level500.shellsaga.ShellSagaApplication;
import com.level500.shellsaga.config.GameConstants;
import com.level500.shellsaga.converters.EquipmentConverter;
import com.level500.shellsaga.core.game.entities.enums.EquipmentSlot;
import com.level500.shellsaga.core.game.items.Equipment;
import com.level500.shellsaga.core.game.items.EquipmentStats;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

@Entity
@Table(name="players")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Player {

    private static final Logger logger = LoggerFactory.getLogger(ShellSagaApplication.class);
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private int level;

    // 🔥 Base stats (before equipment bonuses)
    private int baseHp;
    private int baseMana;
    private int baseAttackPower;
    private int baseDefense;
    private int baseSpeed;
    private double baseCritRate;
    private double baseCritMultiplier;

    // 🔥 Current stats (modified by equipment)
    private int enhancedHp;
    private int enhancedMana;
    private int enhancedAttackPower;
    private int enhancedDefense;
    private int enhancedSpeed;
    private double enhancedCritRate;
    private double enhancedCritMultiplier;

    @Transient
    private int hp = GameConstants.DEFAULT_HP;
    @Transient
    private int mana = GameConstants.DEFAULT_MANA;
    @Transient
    private int attackPower = GameConstants.DEFAULT_ATTACK_POWER;
    @Transient
    private int defense = GameConstants.DEFAULT_DEFENSE;
    @Transient
    private int speed = GameConstants.DEFAULT_SPEED;
    @Transient
    private double critRate = 0;
    @Transient
    private double critMultiplier = 0;



    private int xp = 0;  // ✅ XP Tracking
    // ✅ Gold & STK Management


    @Enumerated(EnumType.STRING)
    private Playstyle playStyle;

    @Column(nullable = false)
    private String currentArea = "Starting Town"; // 🔥 Default starting location

    // ✅ Returns Maximum HP based on level
    @JsonIgnore // ✅ Prevents Redis from serializing `getMaxHp`
    public int getMaxHp() {
        return this.baseHp;
    }

    // ✅ XP Needed for Next Level
    public int calculateXPForNextLevel() {
        return (this.level+1) * 100;
    }

    // ✅ Player Gains XP and Levels Up
    public void gainXp(int amount) {
        this.xp += amount;
        if (this.xp >= calculateXPForNextLevel()) {
            levelUp();
        }
    }
    public void levelUp(){
        this.level++;
        this.baseHp += this.level * 10;
        this.hp = getMaxHp();
        this.baseMana += 5;
        this.xp = 0;
        logger.info("🎉 {} leveled up to Level {}!", name, level);
    }

    @Getter
    @JdbcTypeCode(SqlTypes.JSON) // ✅ Supports JSON type for PostgreSQL
    @Column(columnDefinition = "jsonb") // ✅ Stores inventory as JSON in PostgreSQL
    private Map<String, Integer> inventory = new HashMap<>();

    @Getter
    @Setter


    @Column(columnDefinition = "jsonb") // ✅ Stores equipment as JSONB
    @JdbcTypeCode(SqlTypes.JSON)
    @Convert(converter = EquipmentConverter.class)
    private List<Equipment> equipment = new ArrayList<>(); // ✅ Store all owned equipment

    public void addEquipment(Equipment item) {
        equipment.add(item);
    }
    public void removeEquipment(Equipment item) {
        equipment.remove(item);
    }

    public Optional<Equipment> getEquippedItem(EquipmentSlot slot) {
        return equipment.stream().filter(e -> e.getSlot() == slot && e.isEquipped()).findFirst();
    }

    public void equipItem(Equipment item) {
        EquipmentSlot slot = item.getSlot();

        //Check if an item is already equipped in this slot
        getEquippedItem(slot).ifPresent(existingItem -> {
            logger.info("Replacing {} with {}", existingItem.getName(), item.getName());
            unEquipItem(slot);
        });
        // ✅ Unequip any existing item in that slot
        getEquippedItem(item.getSlot()).ifPresent(existing -> existing.setEquipped(false));

        // ✅ Equip new item
        item.setEquipped(true);
        applyEquipmentStats(item);
        // ✅ Recalculate stats
        //recalculateStats();
    }

    private void applyEquipmentStats(Equipment item) {
        EquipmentStats stats = item.getStats();
        this.attackPower += stats.getAttack();
        this.defense += stats.getDefense();
        this.speed += stats.getSpeed();
        this.hp += stats.getHpIncrease();
        this.baseHp += stats.getHpIncrease();
        this.mana += stats.getManaIncrease();
        this.critRate += stats.getCritRate();
        this.critMultiplier += stats.getCritMultiplier();
    }

    private void removeEquipmentStats(Equipment item) {
        EquipmentStats stats = item.getStats();
        this.attackPower -= stats.getAttack();
        this.defense -= stats.getDefense();
        this.speed -= stats.getSpeed();
        this.hp -= stats.getHpIncrease();
        this.baseHp -= stats.getHpIncrease();
        this.mana -= stats.getManaIncrease();
        this.critRate -= stats.getCritRate();
        this.critMultiplier -= stats.getCritMultiplier();
    }

    public void unEquipItem(EquipmentSlot slot) {
        getEquippedItem(slot).ifPresent(existingItem -> {
            existingItem.setEquipped(false);
            removeEquipmentStats(existingItem);
            logger.info("Unequipped: {}", existingItem.getName());
        });

        // ✅ Recalculate stats after unequipping
        //recalculateStats();
    }
    public void addItem(String item, int quantity) {
        inventory.put(item, inventory.getOrDefault(item, 0) + quantity);
    }

    public boolean hasItem(String item) {
        return inventory.containsKey(item);
    }

    public int getItemQuantity(String item) {
        return inventory.getOrDefault(item, 0);
    }

    public void removeItem(String item, int quantity) {
        inventory.put(item, Math.max(inventory.getOrDefault(item, 0) - quantity, 0));
    }



    public void recalculateStats() {
        // Reset base stats
        this.attackPower =  baseAttackPower;
        this.defense =  baseDefense;
        this.speed =  baseSpeed;
        this.hp =  baseHp;
        this.mana = baseMana;
        this.critRate = baseCritRate;
        this.critMultiplier = baseCritMultiplier;

        // Apply bonuses from equipped gear
        this.attackPower +=  this.enhancedAttackPower;
        this.defense +=  this.enhancedDefense;
        this.speed +=  this.enhancedSpeed;
        this.hp +=  this.enhancedHp;
        this.mana += this.enhancedMana;
        this.critRate += this.enhancedCritRate;
        this.critMultiplier += this.enhancedCritMultiplier;


    }



    public static Player createNewPlayer(String name, Playstyle playstyle) {
        return Player.builder()
                .name(name)
                .level(1)
                .baseHp(GameConstants.DEFAULT_HP)
                .baseMana(GameConstants.DEFAULT_MANA)
                .baseAttackPower(GameConstants.DEFAULT_ATTACK_POWER)
                .baseDefense(GameConstants.DEFAULT_DEFENSE)
                .baseSpeed(GameConstants.DEFAULT_SPEED)
                .baseCritRate(0)
                .baseCritMultiplier(0)
                .enhancedHp(GameConstants.ENHANCED_HP)
                .enhancedMana(GameConstants.ENHANCED_MANA)
                .enhancedAttackPower(GameConstants.ENHANCED_ATTACK_POWER)
                .enhancedDefense(GameConstants.ENHANCED_DEFENSE)
                .enhancedSpeed(GameConstants.ENHANCED_SPEED)
                .enhancedCritRate(0)
                .enhancedCritMultiplier(0)
                .hp(GameConstants.DEFAULT_HP)
                .mana(GameConstants.DEFAULT_MANA)
                .attackPower(GameConstants.DEFAULT_ATTACK_POWER)
                .defense(GameConstants.DEFAULT_DEFENSE)
                .speed(GameConstants.DEFAULT_SPEED)
                .critRate(0)
                .critMultiplier(0)
                .playStyle(playstyle)
                .currentArea("Terminus")
                .inventory(new HashMap<>())
                .equipment(new ArrayList<>())
                .build();
    }

    @Override
    public String toString() {
        return "Player{name='" + name + "', level=" + level + ", hp=" + hp + ", mana=" + mana +
                ", attackPower=" + attackPower + ", defense=" + defense +
                ", speed=" + speed + ", currentArea='" + currentArea + "'}";
    }
}
