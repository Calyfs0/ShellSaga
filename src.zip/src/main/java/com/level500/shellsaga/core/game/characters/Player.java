package com.level500.shellsaga.core.game.characters;

import jakarta.persistence.*;
import lombok.*;
import java.util.*;

@Entity
@Table(name = "players")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Player {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private int level;
    private int experience;

    // 🔥 Base stats (before equipment bonuses)
    private int baseHp;
    private int baseMana;
    private int baseAttackPower;
    private int baseDefense;
    private int baseSpeed;

    // 🔥 Enhanced stats (from equipment bonuses)
    private int enhancedHp;
    private int enhancedMana;
    private int enhancedAttackPower;
    private int enhancedDefense;
    private int enhancedSpeed;

    private int receivedDamage = 0;

    // ✅ Set Current Area
    // ✅ Get Current Area
    // ✅ Track Player's Current Area
    @Setter
    @Getter
    @Column(nullable = false)
    private String currentArea = "Terminus";

    // ✅ Get Total HP
    public int getTotalHp() {
        return Math.max(0, baseHp + enhancedHp - receivedDamage);
    }

    // ✅ Get Total Mana
    public int getTotalMana() {
        return baseMana + enhancedMana;
    }

    // ✅ Get Total Attack Power
    public int getTotalAttackPower() {
        return baseAttackPower + enhancedAttackPower;
    }

    // ✅ Get Total Defense
    public int getTotalDefense() {
        return baseDefense + enhancedDefense;
    }

    // ✅ Get Total Speed
    public int getTotalSpeed() {
        return baseSpeed + enhancedSpeed;
    }

    @Override
    public String toString() {
        return "Player{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", level=" + level +
                ", experience=" + experience +
                ", totalHp=" + getTotalHp() +
                ", totalMana=" + getTotalMana() +
                ", totalAttackPower=" + getTotalAttackPower() +
                ", totalDefense=" + getTotalDefense() +
                ", totalSpeed=" + getTotalSpeed() +
                ", currentArea='" + getCurrentArea() + "'" +
                '}';
    }

    // Inventory Handling Methods

    // ✅ Inventory Handling Methods

    private Map<String, Integer> inventory = new HashMap<>();

    public void addItem(String itemName, int quantity) {
        inventory.put(itemName, inventory.getOrDefault(itemName, 0) + quantity);
    }

    public void removeItem(String itemName) {
        inventory.remove(itemName);
    }

    public boolean hasItem(String itemName) {
        return inventory.containsKey(itemName);
    }

    public void displayInventory() {
        System.out.println("\n📦 Inventory:");
        if (inventory.isEmpty()) {
            System.out.println(" - Empty");
        } else {
            inventory.forEach((item, quantity) -> System.out.println(" - " + item + " x" + quantity));
        }
    }
}
