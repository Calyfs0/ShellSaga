package com.level500.shellsaga;

import com.level500.shellsaga.cli.GameCommand;
import com.level500.shellsaga.cli.GameLoop;
import com.level500.shellsaga.core.game.factories.EnemyFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class ShellSagaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShellSagaApplication.class, args);
		System.out.println("\uD83C\uDFAE Welcome to ShellSaga!");
	}
	@Bean
	public GameLoop gameLoop(List<GameCommand> commands) throws Exception {
		return new GameLoop(commands);
	}

	@Bean
	CommandLineRunner runGameLoop(ApplicationContext context) {
		return args -> {
			GameLoop gameLoop = context.getBean(GameLoop.class);
			gameLoop.start();
		};
	}
}
