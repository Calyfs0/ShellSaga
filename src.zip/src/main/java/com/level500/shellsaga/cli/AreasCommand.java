package com.level500.shellsaga.cli;

import com.level500.shellsaga.core.game.characters.Enemy;
import com.level500.shellsaga.core.game.characters.Player;
import com.level500.shellsaga.core.game.locations.Area;
import com.level500.shellsaga.infrastructure.database.AreaRepository;
import com.level500.shellsaga.infrastructure.database.EnemyRepository;
import com.level500.shellsaga.services.PlayerService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.jline.reader.LineReader;
import org.jline.reader.LineReaderBuilder;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
public class AreasCommand implements GameCommand {
    private final PlayerService playerService;
    private final AreaRepository areaRepository;
    private final EnemyRepository enemyRepository;
    private final LineReader reader;

    private final Map<Long, Long> playerSessions = new HashMap<>(); // ✅ Multi-player safe storage

    @Autowired
    public AreasCommand(PlayerService playerService, AreaRepository areaRepository, EnemyRepository enemyRepository) throws Exception {
        this.playerService = playerService;
        this.areaRepository = areaRepository;
        this.enemyRepository = enemyRepository;

        Terminal terminal = TerminalBuilder.builder().system(true).build();
        this.reader = LineReaderBuilder.builder().terminal(terminal).build();
    }

    @Override
    public void execute() {

            String playerIdInput = reader.readLine("\nEnter your player ID: ").trim();
            long playerId;

            try {
                playerId = Long.parseLong(playerIdInput);
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input. Please enter a valid numeric player ID.");
                return;
            }

            Optional<Player> optionalPlayer = playerService.getPlayerById(playerId);
            if (optionalPlayer.isEmpty()) {
                System.out.println("❌ Player not found! Please enter a valid player ID.");
                return;
            }

            playerSessions.put(playerId, playerId); // ✅ Store player ID in session

            Player player = optionalPlayer.get();

        // Fetch areas available based on level
        List<Area> availableAreas = areaRepository.findByLevelRequirementLessThanEqual(player.getLevel());
        if (availableAreas.isEmpty()) {
            System.out.println("❌ No areas available for your level.");
            return;
        }

        System.out.println("\n🌍 Available Areas:");
        for (int i = 0; i < availableAreas.size(); i++) {
            System.out.println((i + 1) + ". " + availableAreas.get(i).getName() + " (Min Level: " + availableAreas.get(i).getLevelRequirement() + ")");
        }

        String choiceInput = reader.readLine("\nSelect an area to move to (enter number): ").trim();
        int choice;
        try {
            choice = Integer.parseInt(choiceInput);
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid input. Please enter a valid number.");
            return;
        }

        if (choice < 1 || choice > availableAreas.size()) {
            System.out.println("❌ Invalid selection. Please try again.");
            return;
        }

        Area selectedArea = availableAreas.get(choice - 1);

        // Update player's current location
        player.setCurrentArea(selectedArea.getName());
        playerService.savePlayer(player);

        System.out.println("\n🚶 Moving to " + selectedArea.getName() + "...");

        // Fetch and display enemies with a level >= player's level
        List<Enemy> enemies = enemyRepository.findByAreaAndLevelGreaterThanEqual(selectedArea, player.getLevel());
        if (enemies.isEmpty()) {
            System.out.println("\n🛡️ This area seems safe... No enemies found!");
        } else {
            System.out.println("\n⚔️ Enemies in " + selectedArea.getName() + " (Minimum Level: " + player.getLevel() + "):");
            for (Enemy enemy : enemies) {
                System.out.println("  - " + enemy.getName() + " (Level: " + enemy.getLevel() + ")");
            }
        }
    }

    public long getStoredPlayerId(Long playerId){
        return playerSessions.get(playerId);
    }

}
