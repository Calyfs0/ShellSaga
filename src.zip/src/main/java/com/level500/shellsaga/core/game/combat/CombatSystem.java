package com.level500.shellsaga.core.game.combat;

import com.level500.shellsaga.core.game.characters.Enemy;
import com.level500.shellsaga.core.game.characters.Player;

public class CombatSystem {
    public static void startBattle(Player player, Enemy enemy) {
        System.out.println("\n⚔️ The battle begins!");
        System.out.println(player.getName() + " VS " + enemy.getName());

        // ✅ Combat logic will be implemented in the next step
    }
}
