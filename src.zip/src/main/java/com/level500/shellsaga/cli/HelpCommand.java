package com.level500.shellsaga.cli;

import lombok.Setter;
import org.springframework.stereotype.Component;

@Component
public class HelpCommand implements GameCommand{
    @Setter
    private static boolean gameStarted = false;

    @Override
    public void execute() {
        System.out.println("\uD83C\uDFAE \nAvailable commands:");
        System.out.println("\uD83D\uDCCC start - Begin your adventure");
        System.out.println("\uD83D\uDCCC help - Show available commands");
        System.out.println("\uD83D\uDCCC exit - Quit the game");

        if(gameStarted){
            System.out.println("\uD83C\uDF0D areas - List available areas");
        }

    }
}
