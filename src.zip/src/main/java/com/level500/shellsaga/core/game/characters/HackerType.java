package com.level500.shellsaga.core.game.characters;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class HackerType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name; // Example: "Cipher Specialist", "Exploit Engineer"
    private String description; // Specialization details

    private int attackBonus;
    private int defenseBonus;
    private int speedBonus;
}
