package com.level500.shellsaga.cli;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.jline.reader.LineReader;
import org.jline.reader.LineReaderBuilder;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class GameLoop {
    private final Map<String, GameCommand> commandMap = new HashMap<>();
    private final LineReader reader;

    @Autowired
    public GameLoop(List<GameCommand> commands) throws Exception {
        // ✅ Initialize terminal for input reading
        Terminal terminal = TerminalBuilder.builder().system(true).build();
        this.reader = LineReaderBuilder.builder().terminal(terminal).build();

        // ✅ Register all available commands dynamically
        registerCommands(commands);
    }

    private void registerCommands(List<GameCommand> commands) {
        System.out.println("\uD83D\uDCCC Registering available commands...");
        for (GameCommand command : commands) {
            String commandName = command.getClass().getSimpleName().replace("Command", "").toLowerCase();
            commandMap.put(commandName, command);
            System.out.println("✅ Registered command: " + commandName);
        }
    }

    public void start() {
        System.out.println("\n🎮 Welcome to ShellSaga!");
        System.out.println("🔹 Type 'start' to begin, or 'help' for available commands.");

        while (true) {
            String input = reader.readLine("\n> ").trim().toLowerCase();

            if (commandMap.containsKey(input)) {
                commandMap.get(input).execute();
            } else {
                System.out.println("❌ Invalid command. Type 'help' for a list of commands.");
            }
        }
    }
}
